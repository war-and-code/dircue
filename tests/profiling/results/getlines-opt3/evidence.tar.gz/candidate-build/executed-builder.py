#!/usr/bin/env python3
"""Build an explicitly dirty getLines overlay over one exact committed snapshot."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import types

ROOT = Path(__file__).resolve().parents[2]
BASE = '390ce5fbcb605eec72af524368d03bdf53715b24'
WORK = ROOT / '.cache/getlines-opt3'
APP = WORK / 'application'
OUT = WORK / 'build'
PATCH = WORK / 'getlines.patch'
MANAGED = WORK / 'integration/enry-linguist-9.7.patch'
ARCHIVE = ROOT / '.cache/enry-library-inputs-rc1/linguist-9.7.0.tar.gz'
MODEL = ROOT / '.cache/identifier-opt1/model.json'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def tree_hashes(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('Unexpected source symlink: ' + str(path))
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


receipt = {'schema_version': '1.0.0', 'complete': False, 'base_commit': BASE,
           'candidate_is_clean_commit': False, 'scope': 'Exact committed regular blobs plus explicit getLines source/test, managed patch and regenerated provenance overlays; correctness/build only',
           'started_at_utc': now(), 'commands': [], 'builds': {}}


def run(label, argv, cwd, env=None):
    print(label, flush=True)
    stdout = OUT / (label + '.stdout.log')
    stderr = OUT / (label + '.stderr.log')
    command = {'label': label, 'argv': [str(a) for a in argv], 'cwd': str(cwd), 'started_at_utc': now()}
    if env is not None:
        command['go_environment'] = {k: v for k, v in env.items() if k.startswith(('GO', 'CGO_'))}
    receipt['commands'].append(command)
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(command['argv'], cwd=cwd, env=env, stdout=out, stderr=err)
    command.update(exit_code=result.returncode, completed_at_utc=now(), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    save('partial-receipt.json', receipt)
    if result.returncode:
        raise RuntimeError(label + ' failed: ' + stderr.read_text(errors='replace')[-6000:] + stdout.read_text(errors='replace')[-3000:])
    return stdout.read_text()


try:
    if APP.exists():
        raise RuntimeError('application snapshot must be fresh')
    if sha(PATCH) != '2d93966e446d39b676af48c9c64e1a78cf7a236d8707e9df704b29a86c709809' or sha(MANAGED) != '8df68091b5058e98a9903c93657cd0259cd0eddb3b293838cd4fe480d1233491':
        raise RuntimeError('Reviewed overlay hash changed')
    # The release helper itself is read from the requested commit, not a mutable
    # worktree module. It copies only regular Git blobs through cat-file --batch.
    helper_source = subprocess.check_output(['git', 'show', BASE + ':scripts/release.py'], cwd=ROOT)
    helper = types.ModuleType('committed_release_helper')
    helper.__file__ = str(OUT / 'committed-release.py')
    Path(helper.__file__).write_bytes(helper_source)
    exec(compile(helper_source, helper.__file__, 'exec'), helper.__dict__)
    APP.mkdir()
    print('snapshot exact committed blobs', flush=True)
    file_count = helper.snapshot(ROOT, BASE, APP)
    inventory = {}
    rows = subprocess.check_output(['git', 'ls-tree', '-r', '-l', '-z', BASE], cwd=ROOT).split(b'\0')
    for row in filter(None, rows):
        meta, raw_path = row.split(b'\t', 1)
        mode, kind, oid, size = meta.split()
        name = raw_path.decode()
        path = APP / name
        size = int(size)
        if kind != b'blob' or mode not in (b'100644', b'100755'):
            raise RuntimeError('Nonregular committed input')
        actual_oid = hashlib.sha1(f'blob {size}\0'.encode())
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                actual_oid.update(block)
        if path.stat().st_size != size or actual_oid.hexdigest() != oid.decode() or bool(path.stat().st_mode & 0o111) != (mode == b'100755'):
            raise RuntimeError('Snapshot identity mismatch: ' + name)
        inventory[name] = {'mode': mode.decode(), 'bytes': size, 'git_blob_oid': oid.decode(), 'sha256': sha(path)}
    if len(inventory) != file_count:
        raise RuntimeError('Snapshot population mismatch')
    save('base-source-manifest.json', {'base_commit': BASE, 'files': inventory})
    before = {name: item['sha256'] for name, item in inventory.items()}
    if tree_hashes(APP) != before:
        raise RuntimeError('Snapshot has missing or extra files')
    run('apply-getlines', ['git', 'apply', '--unsafe-paths', '--directory=' + str(APP), str(PATCH)], ROOT)
    after_overlay = tree_hashes(APP)
    overlay_paths = {'third_party/go-enry/data/generated.go', 'third_party/go-enry/data/generated_lines_test.go'}
    changes = {name for name in set(before) | set(after_overlay) if before.get(name) != after_overlay.get(name)}
    if changes != overlay_paths:
        raise RuntimeError('Unexpected runtime overlay changes: ' + repr(changes))
    shutil.copyfile(MANAGED, APP / 'third_party/patches/enry-linguist-9.7.patch')
    receipt['overlay'] = {'runtime_patch_sha256': sha(PATCH), 'managed_patch_sha256': sha(MANAGED), 'runtime_changed_paths': sorted(changes)}
    receipt['snapshot_file_count'] = file_count
    receipt['base_source_manifest_sha256'] = sha(OUT / 'base-source-manifest.json')
    receipt['inputs'] = {'archive': str(ARCHIVE), 'archive_sha256': sha(ARCHIVE), 'model': str(MODEL), 'model_sha256': sha(MODEL)}
    run('regenerate-fork', ['python3', 'third_party/update_enry.py', '--archive', str(ARCHIVE), '--model', str(MODEL), '--output', str(OUT / 'regenerated')], APP)
    generated = OUT / 'regenerated'
    current_fork = APP / 'third_party/go-enry'
    regenerated_hashes, fork_hashes = tree_hashes(generated), tree_hashes(current_fork)
    regenerated_hashes.pop('PROVENANCE.json')
    fork_hashes.pop('PROVENANCE.json')
    if regenerated_hashes != fork_hashes:
        mismatches = sorted(p for p in set(regenerated_hashes) | set(fork_hashes) if regenerated_hashes.get(p) != fork_hashes.get(p))
        raise RuntimeError('Regenerated fork differs from isolated candidate: ' + repr(mismatches))
    shutil.copyfile(generated / 'PROVENANCE.json', current_fork / 'PROVENANCE.json')
    receipt['regeneration'] = {'all_runtime_tests_model_warnings_licenses_equal': True, 'file_count_without_provenance': len(regenerated_hashes), 'provenance_sha256': sha(current_fork / 'PROVENANCE.json')}
    final_source = tree_hashes(APP)
    changed = {p for p in set(before) | set(final_source) if before.get(p) != final_source.get(p)}
    expected_changes = overlay_paths | {'third_party/patches/enry-linguist-9.7.patch', 'third_party/go-enry/PROVENANCE.json'}
    if changed != expected_changes:
        raise RuntimeError('Unexpected final source changes: ' + repr(changed))
    receipt['overlay']['all_changed_paths'] = sorted(changed)
    receipt['overlay']['files'] = {p: {'before_sha256': before.get(p), 'after_sha256': final_source.get(p)} for p in sorted(changed)}
    receipt['source_files_sha256'] = final_source
    save('candidate-source-before-build.json', {'base_commit': BASE, 'candidate_is_clean_commit': False, 'files': final_source})
    caches = OUT / 'fresh-caches'
    environment = helper.build_environment('go1.26.6', caches)
    selection = dict(environment)
    selection.pop('GOMODCACHE')
    compiler_root = run('resolve-compiler', ['go', 'env', 'GOROOT'], APP, selection).strip()
    compiler = Path(compiler_root) / 'bin/go'
    environment['GOTOOLCHAIN'] = 'local'
    version = run('compiler-version', [compiler, 'version'], APP, environment).strip()
    if version != 'go version go1.26.6 darwin/arm64':
        raise RuntimeError('Unexpected exact compiler: ' + version)
    receipt['compiler'] = {'path': str(compiler), 'sha256': sha(compiler), 'version': version, 'bootstrap_go_selection': 'go1.26.6', 'release_helper_sha256': sha(Path(helper.__file__))}
    receipt['environment'] = {k: v for k, v in environment.items() if k.startswith(('GO', 'CGO_'))}
    target_env = dict(environment, GOOS='linux', GOARCH='arm64')
    receipt['environment'].update(GOOS='linux', GOARCH='arm64')
    receipt['go_version'] = version
    receipt['fresh_caches'] = True
    for name, command in [
        ('scanner.test', [compiler, 'test', '-c', '-mod=readonly', '-buildvcs=false', '-trimpath', '-o', OUT / 'scanner.test', './pkg/scanner']),
        ('auragaze', [compiler, 'build', '-mod=readonly', '-buildvcs=false', '-trimpath', '-ldflags', '-s -w -X auragaze/internal/cli.Version=0.1.0', '-o', OUT / 'auragaze', '.']),
    ]:
        run('build-' + name, command, APP, target_env)
        metadata = run('metadata-' + name, [compiler, 'version', '-m', OUT / name], APP, target_env)
        description = run('file-' + name, ['file', OUT / name], APP)
        receipt['builds'][name] = {'sha256': sha(OUT / name), 'bytes': (OUT / name).stat().st_size, 'goos': 'linux', 'goarch': 'arm64', 'metadata': metadata, 'file_description': description, 'stripped': name == 'auragaze'}
        if name == 'scanner.test':
            receipt.update(binary_sha256=sha(OUT / name), binary_modules=metadata,
                           build_command=[str(a) for a in command], file_description=description)
    run('nested-tests', [compiler, 'test', '-mod=readonly', './...', '-count=1'], current_fork, environment)
    run('root-tests', [compiler, 'test', '-mod=readonly', './...', '-count=1'], APP, environment)
    smoke = run('cli-version', ['docker', 'run', '--rm', '--network=none', '-v', str(OUT) + ':/artifacts:ro', '--entrypoint', '/artifacts/auragaze', 'auragaze-linguist:9.7.0', '--version'], APP)
    if smoke.strip() != 'auragaze version 0.1.0':
        raise RuntimeError('Unexpected CLI version output: ' + smoke)
    after = tree_hashes(APP)
    if after != final_source:
        raise RuntimeError('Application source changed during build/tests')
    save('candidate-source-after-build.json', {'base_commit': BASE, 'candidate_is_clean_commit': False, 'files': after})
    receipt['candidate_source_manifest_before_sha256'] = sha(OUT / 'candidate-source-before-build.json')
    receipt['candidate_source_manifest_after_sha256'] = sha(OUT / 'candidate-source-after-build.json')
    receipt['source_unchanged_during_build_and_tests'] = True
    receipt['source_stable_during_build'] = True
    receipt['nested_tests'] = receipt['root_tests'] = receipt['cli_version_smoke'] = 'passed'
    receipt['complete'] = True
    receipt['completed_at_utc'] = now()
    save('build-receipt.json', receipt)
    print(json.dumps({'complete': True, 'builds': {name: value['sha256'] for name, value in receipt['builds'].items()}}), flush=True)
except BaseException as error:
    receipt['error'] = str(error)
    receipt['completed_at_utc'] = now()
    save('partial-receipt.json', receipt)
    raise
