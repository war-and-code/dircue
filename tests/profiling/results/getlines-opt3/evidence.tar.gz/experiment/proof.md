# Bounded generated-file line selection: isolated experiment

Status: isolated focused differential/generated-predicate tests and the full maintained-module suite **PASS**, as recorded in [validation-receipt.json](validation-receipt.json), [focused-tests.log](focused-tests.log) and [maintained-tests.log](maintained-tests.log). No repository corpus gate or performance measurement has run for this experiment. Live source, maintained patch, provenance and baseline binaries remain untouched.

## Evidence and single lever

The RC1 Roslyn allocation profile ranks `bytes.Split` fourth at approximately 279 MiB cumulative allocation; generated-file checks account for 283 MiB, including Haxe's repeated first-three-line requests. These are allocated bytes, not peak RSS. The opportunity scores 4 impact × 5 confidence / 1 effort = 20 in `tests/profiling/results/rc1/README.md`.

Only `getLines` changes. Instead of splitting every LF field and then selecting a few, it finds LF delimiters forward for positive requests or backward for negative requests. `rubyLines`, `forEachLine`, every generated predicate, tokenization, classification, file reads, and concurrency remain unchanged. There are 30 current direct calls using positive constants 1, 2, 3, 5, 6, 10, 20, 30, 40 or negative -2; there are no current zero, MinInt or dynamic requests.

## Equivalence and edge cases

The old oracle is the source helper at `data/generated.go`, SHA256 `ada6d75135dc7cb29dc4280df4c16c2fc9ce044836923e14594cae08f770ff6c`, retained as `generated-before.go.txt`. It uses LF-only `bytes.Split` for nonempty data, retaining trailing empty fields. Prefix selection returns the first fields; suffix selection reverses the final fields.

Forward search returns the same bytes before each LF and stops once the requested prefix is complete. When there is no remaining LF, it returns the unsplit final field. Reverse search returns bytes after the final LF, restricts the remaining prefix to bytes before that delimiter, and repeats. This is precisely the old reversed suffix selection, including final blanks and a leading empty field.

- Ordering preserved: prefixes remain first-to-last; suffixes remain last-to-first.
- Tie-breaking, floating point, production RNG: not involved and unchanged elsewhere.
- Empty content and nonnegative `n`: nil outer result, regardless of whether input was nil or an empty allocated slice.
- Empty content and negative `n`: non-nil empty outer result.
- Nonempty content and `n=0`: non-nil empty outer result.
- `n=MinInt`: negation still overflows and the same negative-capacity `make` operation panics, even on empty input.
- Large positive/negative requests: stop at actual fields without eagerly allocating an unbounded requested count. Initial header capacity is at most eight, growing only for selected fields.
- Raw bytes: only LF separates fields. CR, NUL, BOM bytes, malformed UTF-8 and all other bytes remain unchanged.
- Inner slices: remain views into the original input. A delimiter-ended field has capacity equal to its length; the final suffix retains the input's remaining capacity, matching Go 1.26.6 `bytes.genSplit`. Reverse traversal caps the retained prefix at the delimiter to preserve these same per-field capacities.
- Outer slice capacity intentionally differs: the former complete split reserved headers for every field, even when few were returned. Reducing that backing allocation is the measured objective. No current caller observes outer capacity; elements, order, nil distinctions and inner capacities are preserved.
- Correctness evidence: focused frozen-helper differential and generated-predicate tests PASS; the full isolated maintained suite PASS. Repository inclusion and performance acceptance remain pending.

## Completed tests and remaining acceptance gates

`data/generated_lines_test.go` contains a frozen implementation of the old helper with its original `rubyLines` behavior inlined. It compares results and panic type/message against the candidate, including inner slice capacity and mutations through returned slices into independent equal-capacity source buffers.

Coverage includes every string up to length five over text/LF/CR/NUL, empty/nil/spare-capacity inputs, MinInt/MinInt+1/MaxInt, positive and negative boundary counts, 5,000 seeded random byte inputs, long single lines, many blank fields and CRLF-heavy data. Predicate checks cover marker positions around Haxe 3, Go 40, go-to-protobuf 20, protobuf 3 and Thrift 6; minimum field requirements; JNI/Racc positioning; source-map footer trailing blanks; exact CoffeeScript reverse footer/raw CR handling; and VCR second-to-last fields.

The focused data-package tests and full maintained suite completed successfully; commands, logs and source hashes are retained in the linked validation receipt. Existing all-3,388 sample checks validate labels and ordered tokens, but not `IsGenerated`, and cannot alone accept this change. Require generated predicate/oracle tests plus the CLI conformance and public Git/raw-flat inclusion/byte gates, with Roslyn explicitly checked. Then compare matched Roslyn allocation/time and fresh-process metrics using independent binaries and the same receipts. Re-profile before taking another lever.

## Managed integration and rollback

`getlines.patch` is root-relative and contains only the helper delta plus its new regression test. Apply only after the tokenizer experiment has been accepted and committed, with the base hash verified. Include the new data test in the maintained patch. The updater automatically discovers managed test files from real adjacent patch headers through `patched_test_files`; no separate managed-test list edit is required. Regeneration and provenance verification are required before release. Do not copy the mirror's stale manifest. Before application, discard the isolated experiment to abandon it; after a dedicated commit, revert only that commit.
