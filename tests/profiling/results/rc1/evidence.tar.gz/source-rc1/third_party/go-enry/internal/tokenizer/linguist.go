package tokenizer

import (
	"bytes"
	"regexp"
	"strconv"
	"strings"
)

// LinguistTokenize is a pure-Go port of Linguist 9.7.0 ext/linguist/tokenizer.l.
// Flex chooses the longest match, then the first rule on equal lengths. Go's
// linear-time regexp engine implements this with Longest and ordered branches.
// Tokens have a 16-byte limit; the upstream native scanner reads at most100000B.
func LinguistTokenize(content []byte) []string {
	if len(content) > 100000 {
		content = content[:100000]
	}
	var tokens []string
	emit := func(token string) {
		if len(token) > 16 {
			token = token[:16]
		}
		tokens = append(tokens, token)
	}
	beginning := true
	for len(content) > 0 {
		lexer := ordinaryLexer
		if beginning {
			lexer = beginningLexer
		}
		match := lexer.expression.FindSubmatchIndex(content)
		if match == nil {
			panic("tokenizer fallback failed")
		}
		selected := -1
		for i, index := range lexer.groups {
			if match[index*2] >= 0 {
				selected = i
				break
			}
		}
		rule := lexer.rules[selected]
		size := match[1]
		lexeme := content[:size]
		content = content[size:]
		beginning = lexeme[len(lexeme)-1] == '\n'
		switch rule.action {
		case "feed":
			emit(string(lexeme))
		case "static":
			emit(rule.value)
		case "block":
			emit(rule.value)
			closing := []byte(rule.end)
			index := bytes.Index(content, closing)
			if index < 0 {
				return tokens
			}
			end := index + len(closing)
			beginning = content[end-1] == '\n'
			content = content[end:]
		case "string":
			quote := lexeme[0]
			for len(content) > 0 {
				c := content[0]
				content = content[1:]
				beginning = c == '\n'
				if c == 0 {
					return tokens
				}
				if c == '\n' || c == quote {
					break
				}
				if c == '\\' {
					if len(content) == 0 || content[0] == 0 {
						return tokens
					}
					beginning = content[0] == '\n'
					content = content[1:]
				}
			}
		case "shebang-env", "shebang":
			token := string(lexeme)
			separator := '/'
			if rule.action == "shebang-env" {
				separator = ' '
			}
			if index := strings.LastIndexByte(token, byte(separator)); index >= 0 {
				token = token[index+1:]
			}
			if token != "env" || rule.action == "shebang-env" {
				if len(token) > 16 {
					token = token[:16]
				}
				tokens = append(tokens, "SHEBANG#!"+token)
			}
			for len(content) > 0 {
				c := content[0]
				content = content[1:]
				if c == 0 {
					return tokens
				}
				if c == '\n' {
					beginning = true
					break
				}
			}
		}
	}
	return tokens
}

type lexicalRule struct{ pattern, action, value, end string }
type compiledLexer struct {
	expression *regexp.Regexp
	groups     []int
	rules      []lexicalRule
}

func compileLexer(rules []lexicalRule) compiledLexer {
	parts := make([]string, len(rules))
	for i, rule := range rules {
		parts[i] = "(?P<r" + strconv.Itoa(i) + ">" + rule.pattern + ")"
	}
	expression := regexp.MustCompile("^(?:" + strings.Join(parts, "|") + ")")
	expression.Longest()
	groups := make([]int, len(rules))
	for i := range rules {
		groups[i] = expression.SubexpIndex("r" + strconv.Itoa(i))
	}
	return compiledLexer{expression, groups, rules}
}

var beginningRules = []lexicalRule{
	{`#![ \t]*(?:[A-Za-z0-9_/]*/)?env(?:[ \t]+(?:[^ \t=]*=[^ \t]*))*[ \t]+[A-Za-z_]+`, "shebang-env", "", ""},
	{`#![ \t]*[A-Za-z_/]+`, "shebang", "", ""},
	{`[ \t]*#+(?: .*|\n)`, "static", "COMMENT#", ""},
	{`[ \t]*//!(?: .*|\n)`, "static", "COMMENT//!", ""},
	{`[ \t]*//.*\n?`, "static", "COMMENT//", ""},
	{`[ \t]*--(?: .*|\n)`, "static", "COMMENT--", ""},
	{`[ \t]*%+(?: .*|\n)`, "static", "COMMENT%", ""},
	{`[ \t]*"(?: .*|\n)`, "static", "COMMENT\"", ""},
	{`[ \t]*;+(?: .*|\n)`, "static", "COMMENT;", ""},
	{`\.[ \t]*\\"(?:.*|\n)`, "static", "COMMENT.\\\"", ""},
	{`'[ \t]*\\"(?:.*|\n)`, "static", "COMMENT'\\\"", ""},
	{`\$! (?:.*|\n)`, "static", "COMMENT$!", ""},
	{`\.ig\n`, "block", "COMMENT.ig", "..\n"},
}
var ordinaryRules = []lexicalRule{
	{`/\*\*/`, "static", "COMMENT/*", ""},
	{`/\*\*`, "block", "COMMENT/**", "*/"}, {`/\*!`, "block", "COMMENT/*!", "*/"}, {`/\*`, "block", "COMMENT/*", "*/"},
	{`<!--`, "block", "COMMENT<!--", "-->"}, {`\{-`, "block", "COMMENT{-", "-}"}, {`\(\*`, "block", "COMMENT(*", "*)"},
	{`"""`, "block", "COMMENT\"\"\"", "\"\"\""}, {`'''`, "block", "COMMENT'''", "'''"},
	{`/--`, "block", "COMMENT/-", "-/"}, {`/-`, "block", "COMMENT/-", "-/"},
	{`""|''`, "skip", "", ""}, {`"|'`, "string", "", ""},
	{`(?:0x[0-9a-fA-F](?:[0-9a-fA-F]|\.)*|[0-9](?:[0-9]|\.)*)(?:[uU][lL]{0,2}|(?:[eE][-+][0-9]*)?[fFlL]*)`, "skip", "", ""},
	{`[.@#$]?[A-Za-z0-9_]+`, "feed", "", ""},
	{`\(+\)+|\{+\}+|\[+\]+|\(+|\)+|\{+|\}+|\[+|\]+|\$(?:\(+|\{+|\[\]+)`, "feed", "", ""},
	{`\(\.\.\.\)|\{\.\.\.\}|\[\.\.\.\]`, "feed", "", ""},
	{`&>|<&|<&-|&>>|>&|\|&|&\|`, "feed", "", ""},
	{`-+>+|<+-+`, "feed", "", ""},
	{`!+=+|[<>]*=+[<>]*|</?[?%!#@]|[?%!]>|[<>/]+|[-+*/%&|^~:]=+|[!=]~|:-`, "feed", "", ""},
	{`\.\*+\??|\.\++\??|\(\?:`, "feed", "", ""},
	{`-+|!+|#+|\$+|%+|&+|\*+|\++|,+|\.+|:+|;+|\?+|@+|\\+|\^+|` + "`" + `+|\|+|~+`, "feed", "", ""},
	{`(?s:.)`, "skip", "", ""},
}
var ordinaryLexer = compileLexer(ordinaryRules)
var beginningLexer = compileLexer(append(append([]lexicalRule{}, beginningRules...), ordinaryRules...))
