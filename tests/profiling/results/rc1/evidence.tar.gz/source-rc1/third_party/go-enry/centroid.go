package enry

import (
	"bytes"
	"compress/gzip"
	_ "embed"
	"encoding/json"
	"math"
	"sort"
	"sync"

	"github.com/go-enry/go-enry/v2/internal/tokenizer"
)

// The model is exported from the pinned official Linguist gem. Inference is a
// port of Linguist 9.7.0 Classifier#classify: log TF * inverse class frequency,
// L2 normalization, then normalized centroid similarity. Runtime is pure Go.
//
//go:embed data/centroid_model.json.gz
var centroidModelGzip []byte

type centroidModel struct {
	Vocabulary map[string]int             `json:"vocabulary"`
	ICF        []float64                  `json:"icf"`
	Centroids  map[string]map[int]float64 `json:"centroids"`
}

var centroidOnce sync.Once
var currentCentroids centroidModel

func loadCentroids() {
	reader, err := gzip.NewReader(bytes.NewReader(centroidModelGzip))
	if err != nil {
		panic(err)
	}
	defer reader.Close()
	if err := json.NewDecoder(reader).Decode(&currentCentroids); err != nil {
		panic(err)
	}
}

type centroidClassifier struct{}

func (*centroidClassifier) classify(content []byte, candidates map[string]float64) []string {
	if len(candidates) == 0 {
		return nil
	}
	centroidOnce.Do(loadCentroids)
	// Ruby caps inference at 50KiB, while training sees complete samples.
	if len(content) > 50*1024 {
		content = content[:50*1024]
	}
	counts := map[int]float64{}
	for _, token := range tokenizer.LinguistTokenize(content) {
		if index, ok := currentCentroids.Vocabulary[token]; ok {
			counts[index]++
		}
	}
	if len(counts) == 0 {
		return nil
	}
	// Stable token order avoids map-iteration-dependent floating point noise.
	indices := make([]int, 0, len(counts))
	for index := range counts {
		indices = append(indices, index)
	}
	sort.Ints(indices)
	norm := 0.0
	for _, index := range indices {
		value := (1 + math.Log(counts[index])) * currentCentroids.ICF[index]
		counts[index] = value
		norm += value * value
	}
	norm = math.Sqrt(norm)
	if norm == 0 {
		return nil
	}
	scored := make([]*scoredLanguage, 0, len(candidates))
	for language := range candidates {
		if alias, ok := GetLanguageByAlias(language); ok {
			language = alias
		}
		fsName := language
		if info, err := GetLanguageInfo(language); err == nil && info.FSName != "" {
			fsName = info.FSName
		}
		centroid := currentCentroids.Centroids[fsName]
		score := 0.0
		for _, index := range indices {
			score += (counts[index] / norm) * centroid[index]
		}
		if score > 0 {
			scored = append(scored, &scoredLanguage{language: language, score: score})
		}
	}
	// Ruby preserves candidate order for ties; generated candidates are sorted
	// by canonical name, so make that order explicit before its stable score sort.
	sort.Slice(scored, func(i, j int) bool { return scored[i].language < scored[j].language })
	return sortLanguagesByScore(scored)
}
