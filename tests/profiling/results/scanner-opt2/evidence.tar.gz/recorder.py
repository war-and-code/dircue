import hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path('/Users/gingeleski/Workspace/auragaze');folder=root/'.cache/scanner-profiles-opt2';out=root/'tests/profiling/results/scanner-opt2'
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=module('archive_helpers',root/'tests/enry-performance/record_library.py');runner=module('scanner_runner',root/'tests/profiling/run.py')
sha,encode=h.sha,h.encode
assert not out.exists()
entries={'evidence/'+p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file() and p.name!='scanner.test'}
load=lambda n:json.loads(entries['evidence/'+n])
build=load('build-receipt.json');commit=build['commit']
assert commit=='390ce5fbcb605eec72af524368d03bdf53715b24'
assert sha((folder/'scanner.test').read_bytes())==build['binary_sha256']
assert build['source_unchanged_after_build'] and load('source-before-build.json')['files']==build['source_files_sha256']
for name,digest in build['source_files_sha256'].items():
 b=subprocess.run(['git','show',commit+':'+name],cwd=root,stdout=subprocess.PIPE,check=True).stdout
 assert sha(b)==digest,name
 entries['source/'+name]=b
for name in ['tests/profiling/run.py','tests/profiling/refresh.py','tests/performance/corpus.json']:
 b=subprocess.run(['git','show',commit+':'+name],cwd=root,stdout=subprocess.PIPE,check=True).stdout
 entries['source/'+name]=b
assert sha(entries['source/tests/profiling/run.py'])==build['profile_runner_sha256']
assert sha(entries['source/tests/profiling/refresh.py'])==build['refresh_script_sha256']
ready=load('ready.json')
for name,digest in ready['receipts'].items():assert sha(entries['evidence/'+name])==digest
old_archive=root/'tests/profiling/results/rc1/evidence.tar.gz';old_audit=json.loads((old_archive.parent/'archive-audit.json').read_text())
assert sha(old_archive.read_bytes())==old_audit['archive_sha256'];old_entries=h.unarchive(old_archive.read_bytes())
for group in ['small','dotnet']:
 payload=entries[f'evidence/scanner-{group}-baseline-rc1.json']
 assert any(payload==b for b in old_entries.values()),'historical report absent from immutable RC1 archive'
counts={'measured':0,'warmup':0,'cpu':0,'mem':0};summaries={}
def local(path):return Path(path).relative_to('/build').as_posix()
for group,stage in [('small','baseline'),('dotnet','baseline'),('small','cpu'),('dotnet','mem')]:
 name=f'scanner-{group}-{stage}';report=load(name+'/result.json');assert report['complete']
 identity=report['identity'];assert identity['binary_sha256']==build['binary_sha256'] and identity['runner_sha256']==build['profile_runner_sha256']
 assert identity['pins_sha256']==sha(entries['source/tests/performance/corpus.json'])
 assert identity['gomaxprocs']==5 and identity['include_files']==0 and identity['runtime_environment']=={'GOGC':'100','GOMEMLIMIT':'off','GODEBUG':''}
 for value in identity['receipts'].values():assert sha(entries['evidence/'+local(value['path'])])==value['sha256']
 previous=load(f'scanner-{group}-baseline-rc1.json');assert report['result_digests']==previous['result_digests']
 if stage!='baseline':
  baseline=load(f'scanner-{group}-baseline/result.json')
  assert report['identity']==baseline['identity'] and report['baseline_sha256']==sha(entries[f'evidence/scanner-{group}-baseline/result.json'])
 for sample in report['samples']:
  counts[sample['phase']]+=1;p='evidence/'+local(sample['fingerprint']);assert sha(entries[p])==sample['fingerprint_sha256']
  fingerprint=json.loads(entries[p]);assert fingerprint['result_sha256']==sample['result_sha256']==report['result_digests'][sample['scenario']]
  assert fingerprint['measured_elapsed_ns']==sample['scan_elapsed_ns']
 if stage=='baseline':
  for scenario,s in report['summaries'].items():
   values=[v for v in report['samples'] if v['scenario']==scenario and v['phase']=='measured']
   assert len(values)==report['runs']
   assert runner.distribution([v['scan_elapsed_ns'] for v in values])==s['scan_elapsed_ns']
   assert runner.distribution([v['process_wall_seconds'] for v in values])==s['process_wall_seconds']
   for key,val in s['resources'].items():
    computed=runner.distribution([v['resources'][key] for v in values])
    for metric,expected in val.items():h.equal(computed[metric],expected,'resource '+key+' '+metric)
   summaries[scenario]=s
profile_receipt=load('tops/receipt.json');assert profile_receipt['binary_sha256']==build['binary_sha256']
for value in profile_receipt['outputs']:
 for key,digest in [('profile','profile_sha256'),('stdout','stdout_sha256')]:
  p=Path(value[key]).relative_to('.cache/scanner-profiles-opt2').as_posix();assert sha(entries['evidence/'+p])==value[digest]
assert counts=={'measured':220,'warmup':9,'cpu':2,'mem':1}
lines=['# Scanner profile refresh after lexer subset optimization','',f'Source `{commit}`, Go 1.26.6, optimized unstripped Linux arm64 scanner test binary `{build["binary_sha256"]}`. All 232 baseline/warmup/profile fingerprints match the immutable RC1 full result digests. No scanner binary is included; committed source snapshots and build controls are retained.','',
'| Scenario | Measured runs | Scan median / p95 (s) | Scan CV | Process median (s) | Peak process RSS (MiB) |','|---|---:|---:|---:|---:|---:|']
for name,s in summaries.items():
 w=s['scan_elapsed_ns'];lines.append(f'| {name} | {w["count"]} | {w["median"]/1e9:.6f} / {w["p95"]/1e9:.6f} | {w["coefficient_of_variation"]:.3f} | {s["process_wall_seconds"]["median"]:.6f} | {s["resources"]["max_rss_kib"]["max"]/1024:.1f} |')
lines+=['','Each scenario has 3 excluded warmup processes. All measured scan totals exceed 10 seconds. No samples were discarded. First-scan timing starts after Go package initialization; external process duration includes setup, scanning, fingerprints and shutdown. Filesystem caches were uncontrolled and warmed by integrity verification.','',
'Compared with the separate RC1 window, Roslyn remains essentially unchanged (7.1044 s vs 7.1024 s). Small scans retain high variability: ripgrep 146.1 ms vs 143.1 ms and jq 156.3 ms vs 181.0 ms. These small-case comparisons are diagnostic, not accepted speedup claims.','',
'Separate short CPU profiles identify model loading as a candidate: jq loadCentroids has 90 ms cumulative CPU out of 160 ms total sampled CPU (140 ms tagged phase=scan); ripgrep has 120 ms out of 180 ms total (160 ms tagged). Pprof displays 56.25% and 66.67% using the total-sample denominators. These are only 16 and 18 sampled CPU ticks, so exact rankings/percentages are uncertain. CPU may exceed wall duration because more than one thread contributes.','',
'The separate Roslyn allocation profile reports 2,413.10 MB cumulative allocated space in pprof display units. io.ReadAll accounts for 650.06 MB, MemoryObject.Write 597.44 MB, bufio.NewReaderSize 335.77 MB, and bytes.genSplit 276.06 MB. data.getLines accumulates 275.52 MB (11.42%). This supports a bounded getLines allocation experiment; it does not establish its latency gain. Cumulative allocations include setup/runtime and are distinct from peak RSS and retained heap.','',
'This refresh precedes any getLines or model-startup change. Baselines and profiled invocations are kept separate. Host limits remain Docker Desktop, uncontrolled governor/turbo/SMT and cache state, one historical window per version, and no independent quiet-host trace. No universal or three-window stability claim is made.','',
'`evidence.tar.gz` retains raw profiles, all fingerprints and samples, symbol/build/input receipts, pprof commands and text, committed source snapshots, the recording script and helper, and a per-member SHA-256 manifest. Extract it to inspect or independently replay the calculations; original paths inside receipts identify their measurement-time mounts.','']
readme='\n'.join(lines).encode()
gate={'complete':True,'questions':{'1_workload':'pass: fixed ripgrep/jq raw-blob flat views and pinned packed Roslyn Git source','2_baseline':'pass: separate optimized unprofiled baselines, RC1 outputs byte-identified in its immutable archive','3_correctness':'pass: every full result digest matches RC1; stable digests alone are not a new independent language oracle','4_source':'pass: all built root/fork source snapshots match committed390ce source inventory','5_build':'pass: pinned compiler, normal optimization, unstripped static binary and symmetric runtime controls','6_environment':'waive: Docker VM, uncontrolled governor/turbo/SMT and host interference','7_samples':'pass: 100/100/20, three warmups each, all totals above10seconds','8_distribution':'pass: all samples retained; medians,p95,CV,CPU,RSS independently recomputed','9_order':'pass: seeded order within paired small rounds; Roslyn separate','10_profiler':'pass: profiles separate, labels inspected, retained symbol binary identity','11_three_tiers':'qualified: scan/process/RSS separate; no speedup tier assigned for noisy small historical comparisons','12_cost_scope':'pass: cumulative alloc vs retained heap vs peak RSS distinguished; CPU denominators explicit','13_repetition':'waive: one window per version, no three independent windows','14_reproduction':'qualified: committed source/build/input receipts retained; Docker environment and original named volumes required; no universal claim'}}
audit={'complete':True,'commit':commit,'binary_sha256':build['binary_sha256'],'source_files':len(build['source_files_sha256']),'counts':counts,'all_full_digests_match_rc1':True,'all_summary_distributions_recomputed':True,'all_profile_top_hashes_verified':True,'rc1_archive_sha256':old_audit['archive_sha256']}
entries.update({'README.md':readme,'audit.json':encode(audit),'honest-gate.json':encode(gate),'recorder.py':Path(__file__).read_bytes(),'archive-helpers.py':Path(h.__file__).read_bytes()})
entries['manifest.json']=encode({n:sha(b) for n,b in sorted(entries.items())})
archive=h.archive(entries);decoded=h.unarchive(archive);assert decoded==entries
manifest=json.loads(decoded['manifest.json']);assert {n:sha(b) for n,b in decoded.items() if n!='manifest.json'}==manifest
out.mkdir(parents=True);(out/'evidence.tar.gz').write_bytes(archive);(out/'README.md').write_bytes(readme);(out/'honest-gate.json').write_bytes(encode(gate))
audit.update(archive_sha256=sha(archive),archive_members=len(entries),archive_readback_verified=True)
(out/'archive-audit.json').write_bytes(encode(audit));(out/'SHA256SUMS.json').write_bytes(encode({p.name:sha(p.read_bytes()) for p in out.iterdir()}))
print(json.dumps(audit,indent=2))
