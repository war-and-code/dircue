`ext_mime.db` is the unchanged extension database from mini_mime 1.1.5,
used by the pinned Linguist 9.7.0 comparison image. It is distributed under
the adjacent MIT license. auragaze embeds this data for deterministic
single-file MIME reporting independent of the host operating system.

Upstream: https://github.com/discourse/mini_mime/tree/v1.1.5/lib/db
