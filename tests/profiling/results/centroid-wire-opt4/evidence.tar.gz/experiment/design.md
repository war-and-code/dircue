# Centroid binary wire-format experiment

Status: design only. Do not implement until fresh opt2 cold-process profiles
confirm that centroid loading remains material. This is a separate lever from
the accepted tokenizer work.

Provisional score: **8.3** (impact 5 × confidence 5 / effort 3). The score is
conditional on the new profiles; it is not a performance result.

## Scope and invariant

Change only the embedded model's wire format and loader. The loaded runtime
shape remains exactly:

- `map[string]int` vocabulary,
- `[]float64` ICF values, and
- `map[string]map[int]float64` centroids.

The classifier's token order, normalization, candidate lookup, multiplication,
accumulation and sorting code remain byte-for-byte unchanged. A later flat or
zero-copy representation would change lookup and arithmetic execution and must
be a separately proved experiment.

The pinned model currently contains 24,914 dense vocabulary indices, 765
languages and 144,171 sparse centroid entries. Its canonical JSON is 4,889,877
bytes and its gzip artifact is 1,713,719 bytes. The proposed uncompressed binary
is approximately 2,223,370 bytes, increasing the embedded artifact by about
510 KiB while removing gzip decompression and JSON reflection, numeric-key and
decimal-float parsing from first classifier use.

## Version 1 format

All integers and float bit patterns are little-endian.

1. Eight-byte magic and format version.
2. The 32-byte SHA-256 of the verified canonical source JSON.
3. `uint32` vocabulary, language and total centroid-entry counts.
4. Vocabulary in dense index order: `uint32` UTF-8 byte length followed by the
   token bytes. The record position is the vocabulary index.
5. One ICF `uint64` IEEE-754 bit pattern per vocabulary index.
6. Languages sorted by UTF-8 bytes. Each record contains `uint32` name length,
   name bytes, `uint32` entry count, then entries sorted by index as
   (`uint32` vocabulary index, `uint64` IEEE-754 bit pattern).

The updater generates `data/centroid_model.go` alongside the binary. That file
contains the format version and canonical source SHA derived from the already
verified JSON; the hand-maintained runtime contains neither a duplicate model
hash nor version-specific source identity. The decoder compares the binary
header with these generated constants.

## Loader validation

Use an explicit cursor with checked slicing, `encoding/binary.LittleEndian` and
`math.Float64frombits`. Preallocate final maps and slices from validated counts.
Decode into a local model and assign the package global only after every check
passes. Preserve lazy `sync.Once` initialization and panic on an invalid embedded
artifact, as the current immutable loader does.

Reject:

- wrong magic, format version or generated source SHA;
- count conversion, multiplication or cursor overflow;
- truncation or trailing bytes;
- non-dense or duplicate vocabulary indices/tokens;
- duplicate or non-increasing language names;
- duplicate, non-increasing or out-of-range centroid indices;
- section and total-entry count mismatches; and
- NaN or infinite ICF/centroid values.

Use safe string copies from the embedded bytes. Do not use `unsafe`, generated
map literals, reflection-based binary decoding, or a new compression dependency.

## Updater changes

Continue producing canonical JSON in memory and requiring its existing pinned
SHA-256 before binary generation. Validate exact JSON schema, dense unique
indices, lengths/counts fitting `uint32`, and finite floats. Encode every float
with `struct.pack('<d')`. Independently decode the result in Python and compare
every vocabulary mapping and every packed float bit pattern with the verified
source object before it enters the staged output.

Replace `data/centroid_model.json.gz` with `data/centroid_model.bin` and generated
`data/centroid_model.go`. Record the canonical source SHA, format version and
binary SHA-256 in provenance. Generate before the staged nested-module tests and
the existing transactional directory publication.

## Required proof and gates

1. Retain a one-time migration report from a Go verifier that decodes the old
   canonical JSON and the new binary, comparing every key/index and
   `math.Float64bits` value. A Python-only round trip is insufficient.
2. Add table tests for every malformed-format rejection above and an actual
   model check for the generated source SHA and section counts.
3. Compare classifier score bit patterns, candidate order and labels on focused
   fixtures. The existing sample report proves labels and token sequences, not
   score bits.
4. Run the full nested module and race suites, then the actual Ruby 3,388-sample
   label/token gate.
5. Measure matched fresh-process CLI wall/CPU/RSS and full/prefix library cells.
   Report the roughly 510 KiB artifact increase and mapped-page effect. Reject
   the experiment if fresh opt2 profiles no longer attribute material cost to
   model loading or if any semantic/score-bit gate differs.

