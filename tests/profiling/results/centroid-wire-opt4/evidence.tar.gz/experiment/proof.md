# Centroid wire-format opt4 isolated experiment

Status: the runtime and updater converter remain isolated from live source.
Portable runtime/updater patches, an accepted-opt3 candidate, fresh regeneration,
full/race/application-package tests, source manifests and a final Linux arm64
build receipt are complete. The actual-Ruby sample gate and the
11-public-repository contract gate also pass. The predefined scoped
performance/resource gate now passes. Live integration and the full release
library/CLI matrix remain pending; this is component acceptance rather than a
release-complete claim.

## Evidence and single lever

Fresh opt2 first-scan profiles in `.cache/scanner-profiles-opt2/tops` sampled
90 ms of 160 ms total CPU in `loadCentroids` for jq and 120 ms of 180 ms total
CPU in classifier initialization for ripgrep, including 70 ms in JSON value
decoding. These are coarse diagnostics with only 16 and 18 total ticks, rather
than precise percentage estimates. The previously scored opportunity is 5
impact × 5 confidence / 3 effort = 8.3. This experiment changes only the
embedded centroid wire format and its loader.

The canonical Linguist JSON remains pinned at SHA-256
`13a5bb39a79e60c5bdb08f49c069445e664b475e82a9a65b018590293cd75743`.
The deterministic v1 binary is 2,223,374 bytes with SHA-256
`ddd73e86b34b4e3407ebf41b7aa5ccec1779a3e74a4e736d78b3f40128999a85`.
It replaces the 1,713,719-byte gzip, increasing the embedded artifact by
509,655 bytes. The matched unstripped scanner grew from 14,733,800 to
15,257,844 bytes (+524,044), while the stripped CLI grew from 14,942,370 to
15,466,658 bytes (+524,288, exactly 512 KiB). The scoped RSS effects are
reported in the completed measurement section below.

## Runtime invariants

The decoder constructs the same `map[string]int` vocabulary, `[]float64` ICF,
and `map[string]map[int]float64` centroids. All classifier code beginning with
`type centroidClassifier struct{}` is copied from the accepted source; token
selection, index sorting, TF/ICF multiplication, normalization, centroid
accumulation, candidate handling and score sorting are unchanged.

The v1 header has the eight-byte `AURACENT` magic, a little-endian uint32
version, canonical source SHA-256, and vocabulary/language/entry counts. Tokens
are emitted in dense vocabulary-index order; ICF values use their IEEE-754
uint64 bits. Languages sort by UTF-8 bytes and centroid entries sort by index.
The generated `data/centroid_model.go` carries the source hash, full binary
hash, format version and counts. The hand-maintained loader duplicates none of
that model identity.

`loadCentroids` hashes the complete embedded binary before decoding. The runtime
also requires protocol version 1 independently of the generated metadata, so
changing metadata alone cannot bless an unknown layout. The cursor
uses checked slices and allocation counts bounded by encoded size, rejects
truncation/trailing bytes, invalid UTF-8, metadata/count mismatches, duplicate
tokens, unordered or duplicate languages/indices, out-of-range indices and
nonfinite float values, then publishes the fully decoded local model through
the existing `sync.Once` path. It uses no unsafe conversion or new dependency.

## Correctness evidence

The migration-only Go test embeds the old gzip in the isolated fork and
compares every vocabulary index and every ICF/centroid `math.Float64bits` value
against the binary decoder. It also computes fixed-content candidate scores
through identical arithmetic and compares score bits. Map lookups require key
presence as well as equal values, including zero-valued mappings; explicit
tamper tests cover that case. This test is evidence,
not part of the production patch, so the obsolete gzip does not continue to
ship.

Permanent tests validate the generated binary hash and section counts, a fixed
four-language score-bit fixture, every
byte truncation of a valid miniature model, corrupt magic/version/source/hash,
malformed generated hashes, count bounds, trailing bytes, invalid UTF-8,
duplicate tokens/languages/indices, language/index ordering, out-of-range
indices, total-entry mismatches, and NaN/infinite values. Focused and full test
results and their exact artifact hashes are recorded in the combined component
receipt.

## Updater and remaining gates

The isolated updater validates the exact JSON schema, dense vocabulary,
uint32-sized counts and UTF-8 strings, centroid index bounds/order, and finite
floats. It encodes deterministically, independently decodes the result, and
compares every float's packed bits before staging it. It writes the binary and
generated metadata and records the binary format/hash in provenance. The
existing canonical source hash remains unchanged. Every future refresh also
writes the canonical JSON and an independent Go migration test temporarily into
the unpublished assembled candidate, compares all model mappings and float bits,
then deletes both before provenance/manifest validation. This preserves the Go
oracle without shipping the obsolete JSON.

The final fresh regeneration produced 45 managed files plus provenance. Every
managed hash verifies; all candidate and regenerated bytes match, with only the
expected pre-adoption provenance difference. The adopted provenance SHA-256 is
`11efa652ee3a675f4f80d1d861182e83789f3c1094d74f53eed91588df71091b`;
the old gzip and unpublished migration files are absent. Root independently
reviewed the decoder, updater, runtime-v1 binding, presence checks, regeneration
and all 45 managed hashes and found no source blocker.

The classifier block from `type centroidClassifier struct{}` through EOF is
byte-identical to accepted source: 1,820 bytes, SHA-256
`43283e6b9e9972c45f8b69dfdaaf60442502550b9e168a1b24715f89f7f8ba79`.
The candidate matches actual Ruby on all 3,388 pinned sample labels and ordered
token sequences with zero reference errors and a stable 73-file source inventory.
The candidate's nested full and race suites pass. The isolated application-root
package suite (`auragaze`, `internal/cli`, `pkg/detectors`, `pkg/profile`, and
`pkg/scanner`) passes with process-local Git commit-signing isolation. That
application-root copy intentionally contains no top-level `tests/` directory;
full-repository acceptance remains a later integration gate. The final 73-file build inventory
explicitly includes the binary, excludes the gzip, remained stable during the
Go1.26.6 CGO-disabled Linux arm64 build, and produced scanner SHA-256
`f53002254553f1bd5295268db12ba1d34d2d6fcc251fb43b714d81a259d03320`.

## Scoped performance result

The final candidate and accepted opt3 baseline ran adjacently with reversed
order, 500 measured pairs for each small case and 20 for Roslyn. All result
digests matched. Ripgrep first-scan median improved 4.626× and full-process
median 2.959×; jq improved 3.005× and 2.350× respectively. Small-case allocated
bytes fell 2.437×/2.373×, allocation counts fell 5.277×/4.259×, and peak RSS
fell from 40.9/41.1 MiB to 29.4/29.9 MiB.

Roslyn medians were 1.014× in the candidate's favor, with the paired 95%
interval `[0.987, 1.022]` including parity, so no speed verdict is claimed.
Allocated bytes improved 1.012× and allocation count 1.023×; peak RSS was
344.2 versus 344.5 MiB. This is no material unexplained regression.

These measurements are one Docker Desktop window with uncontrolled OS cache,
governor/turbo/SMT and host interference. First-scan excludes Go package
initialization, while process timing includes it. The result accepts this
specific centroid-loading lever; it does not establish a universal speedup.
Full release library and CLI matrices remain required after live integration.
