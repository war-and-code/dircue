#!/usr/bin/env python3
"""Encode the verified Linguist centroid JSON into auragaze wire format v1."""

import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
import struct

MAGIC = b"AURACENT"
FORMAT_VERSION = 1
EXPECTED_SOURCE_SHA256 = "13a5bb39a79e60c5bdb08f49c069445e664b475e82a9a65b018590293cd75743"
U32 = struct.Struct("<I")
U64 = struct.Struct("<Q")


def require_u32(value, description):
    if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 0xFFFFFFFF:
        raise ValueError(f"{description} does not fit uint32")
    return value


def finite_float(value, description):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError(f"{description} is not numeric")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{description} is not finite")
    return value


def text_bytes(value, description):
    if not isinstance(value, str):
        raise ValueError(f"{description} is not a string")
    encoded = value.encode("utf-8")
    require_u32(len(encoded), f"{description} length")
    return encoded


def validated_model(model):
    if not isinstance(model, dict) or set(model) != {"vocabulary", "icf", "centroids"}:
        raise ValueError("centroid model must contain exactly vocabulary, icf, and centroids")
    vocabulary = model["vocabulary"]
    icf = model["icf"]
    centroids = model["centroids"]
    if not isinstance(vocabulary, dict) or not isinstance(icf, list) or not isinstance(centroids, dict):
        raise ValueError("invalid centroid model section type")
    require_u32(len(vocabulary), "vocabulary count")
    require_u32(len(centroids), "language count")
    if len(icf) != len(vocabulary):
        raise ValueError("ICF length does not match vocabulary count")
    by_index = [None] * len(vocabulary)
    for token, index in vocabulary.items():
        token_bytes = text_bytes(token, "vocabulary token")
        require_u32(index, "vocabulary index")
        if index >= len(by_index) or by_index[index] is not None:
            raise ValueError("vocabulary indices are not unique and dense")
        by_index[index] = token_bytes
    if any(token is None for token in by_index):
        raise ValueError("vocabulary indices are not dense")
    icf_values = [finite_float(value, "ICF value") for value in icf]
    languages = []
    total_entries = 0
    for language, entries in centroids.items():
        language_bytes = text_bytes(language, "language name")
        if not isinstance(entries, dict):
            raise ValueError(f"centroid for {language!r} is not an object")
        require_u32(len(entries), "language entry count")
        normalized = []
        for raw_index, value in entries.items():
            if not isinstance(raw_index, str) or not raw_index.isascii() or not raw_index.isdecimal():
                raise ValueError(f"invalid centroid index {raw_index!r}")
            index = int(raw_index, 10)
            require_u32(index, "centroid index")
            if index >= len(by_index):
                raise ValueError("centroid index is outside the vocabulary")
            normalized.append((index, finite_float(value, "centroid value")))
        normalized.sort()
        if any(a[0] == b[0] for a, b in zip(normalized, normalized[1:])):
            raise ValueError("duplicate normalized centroid index")
        total_entries += len(normalized)
        require_u32(total_entries, "total centroid entry count")
        languages.append((language_bytes, normalized))
    languages.sort(key=lambda item: item[0])
    return by_index, icf_values, languages, total_entries


def encode_model(canonical_json):
    source_sha = hashlib.sha256(canonical_json).hexdigest()
    if source_sha != EXPECTED_SOURCE_SHA256:
        raise ValueError(f"canonical model SHA-256 mismatch: {source_sha}")
    model = json.loads(canonical_json)
    tokens, icf, languages, total_entries = validated_model(model)
    output = bytearray(MAGIC)
    output += U32.pack(FORMAT_VERSION)
    output += bytes.fromhex(source_sha)
    output += U32.pack(len(tokens))
    output += U32.pack(len(languages))
    output += U32.pack(total_entries)
    for token in tokens:
        output += U32.pack(len(token))
        output += token
    for value in icf:
        output += struct.pack("<d", value)
    for language, entries in languages:
        output += U32.pack(len(language))
        output += language
        output += U32.pack(len(entries))
        for index, value in entries:
            output += U32.pack(index)
            output += struct.pack("<d", value)
    metadata = {
        "source_sha256": source_sha,
        "binary_sha256": hashlib.sha256(output).hexdigest(),
        "format_version": FORMAT_VERSION,
        "vocabulary_count": len(tokens),
        "language_count": len(languages),
        "centroid_entry_count": total_entries,
    }
    return bytes(output), metadata


def go_metadata(metadata):
    return f'''// Code generated by third_party/update_enry.py; DO NOT EDIT.

package data

const CentroidModelFormatVersion uint32 = {metadata["format_version"]}
const CentroidModelSourceSHA256 = "{metadata["source_sha256"]}"
const CentroidModelBinarySHA256 = "{metadata["binary_sha256"]}"
const CentroidModelVocabularyCount uint32 = {metadata["vocabulary_count"]}
const CentroidModelLanguageCount uint32 = {metadata["language_count"]}
const CentroidModelEntryCount uint32 = {metadata["centroid_entry_count"]}
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("binary", type=Path)
    parser.add_argument("metadata", type=Path)
    args = parser.parse_args()
    raw = args.source.read_bytes()
    canonical = gzip.decompress(raw) if args.source.suffix == ".gz" else raw
    wire, metadata = encode_model(canonical)
    args.binary.write_bytes(wire)
    args.metadata.write_text(go_metadata(metadata))
    print(json.dumps(metadata, sort_keys=True))


if __name__ == "__main__":
    main()
