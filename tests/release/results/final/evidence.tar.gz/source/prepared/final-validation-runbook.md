# Final v0.1 validation — prepared, not executed

Run only after the parent accepts opt4, commits all accepted source/provenance,
and opens the compute gate. Work from `/Users/gingeleski/Workspace/auragaze`.
Keep the final commit and both binaries fixed throughout validation. Preserve RC1
and opt1–4 results. Each command's exit status and stdout/stderr belong in the
fresh output directory; failure stops the sequence. No repeated timing is included.

## Build identity and source checks

Use fresh caches and exact Go1.26.6. Before starting, require clean `git status
--porcelain=v1 --untracked-files=all`, record HEAD and all tracked root/fork source
hashes, and verify the same commit/bytes after builds and checks.

```sh
mkdir .cache/v01-final-validation
mkdir .cache/v01-final-validation/bin .cache/v01-final-validation/logs
export GOENV=off GOWORK=off GOFLAGS= GOEXPERIMENT= GOTOOLCHAIN=go1.26.6
export GOPROXY=https://proxy.golang.org,direct GOSUMDB=sum.golang.org GOAUTH=off
export GOPRIVATE= GONOPROXY= GONOSUMDB= GOINSECURE=
export GOAMD64=v1 GOARM64=v8.0 GODEBUG= GOGC=100 GOMEMLIMIT=off
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=commit.gpgsign GIT_CONFIG_VALUE_0=false
export GOCACHE="$PWD/.cache/v01-final-validation/go-build-cache"
export GOMODCACHE="$PWD/.cache/v01-final-validation/go-module-cache"
unset GOROOT GOOS GOARCH GOMAXPROCS GOMOD
go version
CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 go build -mod=readonly -buildvcs=false -trimpath \
  -ldflags '-s -w -X auragaze/internal/cli.Version=0.1.0' \
  -o .cache/v01-final-validation/bin/auragaze-darwin-arm64 .
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -mod=readonly -buildvcs=false -trimpath \
  -ldflags '-s -w -X auragaze/internal/cli.Version=0.1.0' \
  -o .cache/v01-final-validation/bin/auragaze-linux-arm64 .
python3 tests/performance/receipt.py \
  --candidate .cache/v01-final-validation/bin/auragaze-linux-arm64 \
  --output .cache/v01-final-validation/build-receipt.json
go vet ./...
go test ./...
CGO_ENABLED=1 go test -race ./...
(cd third_party/go-enry && go test ./...)
python3 -m unittest discover -s tests/provenance -v
python3 -m unittest discover -s tests/release -p 'test_packaging.py' -v
```

Git commit signing is disabled only in the validation process environment so fixture commits do not depend on host signing credentials. No user Git configuration is modified.

The opt4 updater/model-specific tests belong to the accepted security-review
patch. The generic Go provenance test hashes every manifest entry and rejects
unmanaged files. The receipt must include `data/centroid_model.bin`; the prepared
one-line receipt change adds `*.bin` to its tracked input inventory.

## Native CLI and independent Ruby samples

```sh
python3 tests/conformance/run.py \
  --binary "$PWD/.cache/v01-final-validation/bin/auragaze-darwin-arm64" \
  --image auragaze-linguist:9.7.0 \
  --output .cache/v01-final-validation/cli.json
python3 tests/conformance/samples.py --require-match \
  --archive .cache/enry-library-inputs-rc1/linguist-9.7.0.tar.gz \
  --image auragaze-linguist:9.7.0 \
  --output .cache/v01-final-validation/samples.json
```

Require420CLI cases with404PASS/16independently validatedXFAIL/0FAIL, plus3388
candidate labels and3388ordered token sequences matching actualRuby. The sample
script builds separate classifier/token probes; bind their report to the same
before/after source inventory. The independent officialEnry probe must retain
its expected module sum and absent replacement.

## Public11 and stress14 correctness only

Confirm the existing stress manifest is `/stress/acceptance-final/manifest.json`
in `auragaze-stress-v1` before invoking its harness. Do not regenerate fixtures.
The public source volume is `auragaze-v01-corpus-20260907`; Git CLI correctness
uses these original committed trees, not the separately materialized flat views.

```sh
docker run --rm --network=none \
  -v auragaze-v01-corpus-20260907:/corpus:ro \
  -v "$PWD/tests/performance:/harness:ro" \
  -v "$PWD/.cache/v01-final-validation:/results" \
  --entrypoint python3 auragaze-linguist:9.7.0 \
  /harness/compare.py --corpus /corpus \
  --candidate /results/bin/auragaze-linux-arm64 \
  --runs 0 --warmup 0 --output /results/public-correctness.json
docker run --rm --network=none \
  -v auragaze-stress-v1:/stress:ro \
  -v "$PWD/tests/stress:/harness:ro" \
  -v "$PWD/.cache/v01-final-validation:/results" \
  --entrypoint python3 auragaze-linguist:9.7.0 \
  /harness/compare.py --fixtures /stress/acceptance-final \
  --candidate /results/bin/auragaze-linux-arm64 \
  --build-receipt /results/build-receipt.json \
  --runs 0 --warmup 0 --output /results/stress-correctness.json
```

Require complete finished reports with11public/14stress cases and exact output
contracts. Reopen every retained output and verify its hash. Zero-run reports
retain diagnostic resource readings; they are not accepted repeated timings.

## Runtime image, platform archives and reproduction

Build image only after clean final runtime freeze. Capture exact image ID and
require extracted image binary SHA equals the cross-built Linux binary.

```sh
docker build --build-arg VERSION=0.1.0 -t auragaze:0.1.0-final .
python3 tests/release/smoke.py --image auragaze:0.1.0-final \
  --corpus-volume auragaze-v01-corpus-20260907 \
  --candidate .cache/v01-final-validation/bin/auragaze-linux-arm64 \
  --output .cache/v01-final-validation/docker-smoke.json
python3 scripts/release.py --version 0.1.0 --output dist/v0.1.0-final
python3 scripts/release.py --version 0.1.0 --target linux/arm64 \
  --output dist/v0.1.0-final-reproduction
python3 - <<'PY'
import hashlib
from pathlib import Path
full = Path('dist/v0.1.0-final')
repeat = Path('dist/v0.1.0-final-reproduction')
rows = (repeat / 'SHA256SUMS').read_text().splitlines()
assert len(rows) == 1
expected, name = rows[0].split()
assert rows[0] in (full / 'SHA256SUMS').read_text().splitlines()
for root in (full, repeat):
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
PY
```

The reproduction comparison selects the one repeated archive; the full run has
five targets. Also compare the extracted binary SHA with the build receipt.
Use the release script's recorded provenance to verify all five archives,
payload modes/names/licenses and executable hashes. Execute darwinarm64 natively
and linuxarm64 inDocker; linuxamd64 smoke underDocker emulation is execution
evidence only. Windows/macOSamd64 remain compile-only unless actual CI is run.

No harness reads the centroid gzip by name except the updater path currently
owned by security_review. Sample probes use normal package embeds. Release
snapshot includes every regular Git blob; the model stays inside the binary and
does not require a runtime sidecar. The new generated metadata must be committed
and covered by the updated fork provenance before any command here runs.
