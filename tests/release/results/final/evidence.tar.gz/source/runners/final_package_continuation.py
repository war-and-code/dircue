import argparse, datetime, fcntl, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, sys
ROOT=pathlib.Path('/Users/gingeleski/Workspace/auragaze')
BASE=ROOT/'.cache/v01-final-validation'
SPEC=importlib.util.spec_from_file_location('final_checks',ROOT/'.cache/final_validation.py')
CHECKS=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(CHECKS)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,v):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');tmp.replace(p)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
parser=argparse.ArgumentParser();parser.add_argument('--commit',required=True);parser.add_argument('--output',type=pathlib.Path,default=ROOT/'.cache/v01-final-packaging');args=parser.parse_args()
out=args.output.resolve();out.mkdir()
with (out/'runner.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    source=CHECKS.source(args.commit);prior=read(BASE/'state.json')
    assert prior['plan']['commit']=='f13f06841a49f4c862319feb88bc2a7549cee06b'
    changes={p:{'before':prior['source_before'].get(p),'after':source.get(p)} for p in sorted(source.keys()|prior['source_before'].keys()) if source.get(p)!=prior['source_before'].get(p)}
    assert set(changes)=={'scripts/release.py','tests/release/test_packaging.py'},changes
    for name,stage in prior['stages'].items():
        if name!='archives':assert stage['status']=='passed'
    for name in ['cli','samples','public','stress','docker-smoke']:
        CHECKS.validate(name,BASE,prior)
    (out/'bin').mkdir();(out/'logs').mkdir()
    for system in ['darwin','linux']:
        binary='auragaze-'+system+'-arm64';shutil.copyfile(BASE/'bin'/binary,out/'bin'/binary);(out/'bin'/binary).chmod(0o755)
        assert sha(out/'bin'/binary)==sha(BASE/'bin'/binary)
    assert sha(out/'bin/auragaze-linux-arm64')=='d4c1011d3d615f303cd8d60760c0eeb8d3f234fda74ac2dfd77aa75e4e8ae637'
    state=dict(schema_version='1.0.0',complete=False,plan={'commit':args.commit},source_before=source,stages={},
        started_at_utc=now(),packaging_only_changes=changes,runtime_sources_unchanged=True,
        accepted_correctness_commit=prior['plan']['commit'],accepted_correctness_state_sha256=sha(BASE/'state.json'),
        accepted_correctness_build_receipt_sha256=sha(BASE/'build-receipt.json'),runner_sha256=sha(__file__),
        validation_helper_sha256=sha(ROOT/'.cache/final_validation.py'),preserved_prior_failure=str(BASE/'logs/archives-1.stderr'))
    write(out/'state.json',state)
    env={k:v for k,v in os.environ.items() if not k.startswith(('GO','CGO_'))}
    env.update(GOENV='off',GOWORK='off',GOFLAGS='',GOTOOLCHAIN='go1.26.6')
    for name,extra in [('archives',[]),('reproduction',['--target','linux/arm64'])]:
        assert CHECKS.source(args.commit)==source
        command=[sys.executable,str(ROOT/'scripts/release.py'),'--version','0.1.0','--output',str(out/name),*extra]
        record=dict(status='running',command=command,started_at_utc=now());state['stages'][name]=record;write(out/'state.json',state)
        with (out/'logs'/(name+'.stdout')).open('wb') as stdout,(out/'logs'/(name+'.stderr')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
            record['pid']=child.pid;write(out/'state.json',state);print('START',name,child.pid,flush=True)
            code=child.wait()
        record.update(exit_code=code,finished_at_utc=now(),status='failed' if code else 'command-passed')
        write(out/'state.json',state);assert code==0
        CHECKS.validate(name,out,state);assert CHECKS.source(args.commit)==source
        record.update(status='passed',artifacts_sha256=CHECKS.artifacts(name,out));write(out/'state.json',state)
        print('PASS',name,flush=True)
    state.update(complete=True,source_after=CHECKS.source(args.commit),finished_at_utc=now());write(out/'state.json',state)
