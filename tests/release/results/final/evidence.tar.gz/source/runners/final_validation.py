#!/usr/bin/env python3
"""Sequential release checks; requires an explicit frozen commit and execution flag."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/Users/gingeleski/Workspace/auragaze')
PHASES = ['build', 'unit', 'conformance', 'repositories', 'package']
IMAGE = 'sha256:f67c429e2b22c0c9691c9e16cceeeee9f2033486b451f5dc0f4278a1783f742c'
GO = '/Users/gingeleski/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.darwin-arm64/bin/go'

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def write(path, value):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
    temporary.replace(path)
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
def source(commit):
    assert git('rev-parse','HEAD').decode().strip() == commit, 'HEAD changed'
    assert not git('status','--porcelain=v1','--untracked-files=all'), 'checkout must remain clean'
    result = {}
    for raw in git('ls-files','-z').split(b'\0'):
        if raw:
            name = os.fsdecode(raw); path = ROOT/name
            assert not path.is_symlink() and path.is_file(), name
            result[name] = sha(path)
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--output', type=Path, default=ROOT/'.cache/v01-final-validation')
    parser.add_argument('--through', choices=PHASES, default='repositories')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--retry-failed', action='store_true', help='Explicitly retry a failed/interrupted stage after its child has stopped')
    a = parser.parse_args(); out = a.output.resolve()
    env = {k:v for k,v in os.environ.items() if not k.startswith(('GO','CGO_','GIT_CONFIG_'))}
    controls = dict(GOENV='off', GOWORK='off', GOFLAGS='', GOEXPERIMENT='', GOTOOLCHAIN='local',
        GOPROXY='https://proxy.golang.org,direct', GOSUMDB='sum.golang.org', GOAUTH='off',
        GOPRIVATE='', GONOPROXY='', GONOSUMDB='', GOINSECURE='', GOAMD64='v1', GOARM64='v8.0',
        GODEBUG='', GOGC='100', GOMEMLIMIT='off', GOCACHE=str(out/'go-build-cache'),
        GOMODCACHE=str(out/'go-module-cache'), GIT_CONFIG_COUNT='1',
        GIT_CONFIG_KEY_0='commit.gpgsign', GIT_CONFIG_VALUE_0='false')
    env.update(controls)
    env['PATH']=str(Path(GO).parent)+os.pathsep+env.get('PATH','')
    stages=[]
    def add(phase,name,command,cwd=ROOT,extra=None):
        stages.append(dict(phase=phase,name=name,command=list(map(str,command)),cwd=str(cwd),environment=extra or {}))
    def docker(name, mounts, command, image=IMAGE):
        args=['docker','run','--rm','--name','auragaze-final-'+name,'--network=none']
        for mount in mounts: args += ['-v',mount]
        return args+['--entrypoint','python3',image]+command
    add('build','compiler',[GO,'version'])
    flags=['-mod=readonly','-buildvcs=false','-trimpath','-ldflags','-s -w -X auragaze/internal/cli.Version=0.1.0']
    for system in ['darwin','linux']:
        add('build','build-'+system,[GO,'build',*flags,'-o',out/'bin'/('auragaze-'+system+'-arm64'),'.'],extra={'CGO_ENABLED':'0','GOOS':system,'GOARCH':'arm64'})
    add('build','build-info-native',[GO,'version','-m',out/'bin/auragaze-darwin-arm64'])
    add('build','build-info-linux',[GO,'version','-m',out/'bin/auragaze-linux-arm64'])
    add('build','native-version',[out/'bin/auragaze-darwin-arm64','--version'])
    add('build','receipt',[sys.executable,ROOT/'tests/performance/receipt.py','--candidate',out/'bin/auragaze-linux-arm64','--output',out/'build-receipt.json'])
    for name,cwd in [('root',ROOT),('nested',ROOT/'third_party/go-enry')]:
        add('unit',name+'-vet',[GO,'vet','./...'],cwd)
        add('unit',name+'-race',[GO,'test','-race','-count=1','-coverprofile='+str(out/(name+'-coverage.out')),'./...'],cwd,{'CGO_ENABLED':'1'})
        add('unit',name+'-coverage',[GO,'tool','cover','-func='+str(out/(name+'-coverage.out'))],cwd)
    for name,directory in [('provenance','tests/provenance'),('packaging','tests/release'),('build-inventory','tests/enry-performance')]:
        add('unit','python-'+name,[sys.executable,'-m','unittest','discover','-s',directory,'-p','test_*.py','-v'])
    add('conformance','cli',[sys.executable,ROOT/'tests/conformance/run.py','--image',IMAGE,'--binary',out/'bin/auragaze-darwin-arm64','--output',out/'cli.json'])
    add('conformance','samples',[sys.executable,ROOT/'tests/conformance/samples.py','--image',IMAGE,'--archive',ROOT/'.cache/enry-library-inputs-rc1/linguist-9.7.0.tar.gz','--require-match','--output',out/'samples.json'])
    common=[str(out)+':/results']
    add('repositories','public',docker('public',['auragaze-v01-corpus-20260907:/corpus:ro',str(ROOT/'tests/performance')+':/harness:ro',*common],['/harness/compare.py','--corpus','/corpus','--candidate','/results/bin/auragaze-linux-arm64','--runs','0','--warmup','0','--output','/results/public.json']))
    add('repositories','stress',docker('stress',['auragaze-stress-v1:/stress:ro',str(ROOT/'tests/stress')+':/harness:ro',*common],['/harness/compare.py','--fixtures','/stress/acceptance-final','--candidate','/results/bin/auragaze-linux-arm64','--build-receipt','/results/build-receipt.json','--runs','0','--warmup','0','--output','/results/stress.json']))
    add('package','docker-build',['docker','build','--build-arg','VERSION=0.1.0','-t','auragaze:0.1.0-final','.'])
    add('package','docker-smoke',[sys.executable,ROOT/'tests/release/smoke.py','--image','auragaze:0.1.0-final','--reference',IMAGE,'--corpus-volume','auragaze-v01-corpus-20260907','--candidate',out/'bin/auragaze-linux-arm64','--output',out/'docker-smoke.json'])
    add('package','archives',[sys.executable,ROOT/'scripts/release.py','--version','0.1.0','--output',out/'archives'])
    add('package','reproduction',[sys.executable,ROOT/'scripts/release.py','--version','0.1.0','--target','linux/arm64','--output',out/'reproduction'])
    selected=[s for s in stages if PHASES.index(s['phase'])<=PHASES.index(a.through)]
    if not a.execute:
        print(json.dumps({'prepared_only':True,'commit':a.commit,'output':str(out),'stages':selected},indent=2));return
    out.mkdir(parents=True,exist_ok=True)
    with (out/'runner.lock').open('a+') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise SystemExit('Another final-validation runner holds the lock; do not restart it.')
        for directory in ['bin','logs']: (out/directory).mkdir(exist_ok=True)
        plan=dict(commit=a.commit,runner_sha256=sha(__file__),environment=controls,stages=stages)
        path=out/'state.json'
        if path.exists():
            state=read(path);assert state['plan']==plan,'runner, commit or command plan changed'
            assert source(a.commit)==state['source_before'],'source changed since first invocation'
        else:
            state=dict(schema_version='1.0.0',plan=plan,started_at_utc=now(),source_before=source(a.commit),stages={},complete=False)
            write(path,state)
        for stage in selected:
            name=stage['name']; old=state['stages'].get(name)
            if old and old['status']=='passed':
                for filename,digest in old.get('artifacts_sha256',{}).items():
                    assert sha(filename)==digest,'completed artifact changed: '+filename
                validate(name,out,state)
                continue
            if old:
                assert a.retry_failed, 'Use --retry-failed only after inspecting the retained failure: '+name
                if old.get('pid'):
                    try: os.kill(old['pid'],0)
                    except ProcessLookupError: pass
                    else: raise RuntimeError('Prior child PID still exists; refusing duplicate work')
                if stage['command'][:2]==['docker','run']:
                    container=stage['command'][stage['command'].index('--name')+1]
                    live=subprocess.run(['docker','inspect','--format','{{.State.Running}}',container],capture_output=True,text=True)
                    assert live.returncode or live.stdout.strip()!='true','Prior Docker container is still running'
            assert source(a.commit)==state['source_before'],'source drift before '+name
            attempt=len(old.get('attempts',[]))+1 if old else 1
            prefix=out/'logs'/f'{name}-{attempt}'
            record=dict(status='running',started_at_utc=now(),command=stage['command'],cwd=stage['cwd'],environment=stage['environment'],stdout=str(prefix)+'.stdout',stderr=str(prefix)+'.stderr',attempts=(old.get('attempts',[])+[old]) if old else [])
            state['stages'][name]=record;write(path,state)
            child=None
            try:
                with open(record['stdout'],'wb') as stdout,open(record['stderr'],'wb') as stderr:
                    child=subprocess.Popen(stage['command'],cwd=stage['cwd'],env=dict(env,**stage['environment']),stdout=stdout,stderr=stderr,start_new_session=True)
                    record['pid']=child.pid;write(path,state)
                    print('START',name,'pid',child.pid,flush=True)
                    code=child.wait();record['exit_code']=code
                assert code==0, 'Command failed; inspect '+record['stderr']
                assert source(a.commit)==state['source_before'],'source drift after '+name
                validate(name,out,state)
                record['artifacts_sha256']=artifacts(name,out)
                record['status']='passed'
            except BaseException as error:
                if child and child.poll() is None:
                    os.killpg(child.pid,signal.SIGTERM);child.wait()
                record['status']='failed';record['error']=repr(error);raise
            finally:
                record['finished_at_utc']=now()
                for key in ['stdout','stderr']:
                    if Path(record[key]).exists():record[key+'_sha256']=sha(record[key])
                write(path,state)
            print('PASS',name,flush=True)
        state['completed_through']=a.through
        state['source_after']=source(a.commit)
        state['complete']=all(s['name'] in state['stages'] and state['stages'][s['name']]['status']=='passed' for s in stages)
        state['last_finished_at_utc']=now();write(path,state)

def validate(name,out,state):
    if name=='compiler': assert 'go version go1.26.6 darwin/arm64' in Path(state['stages'][name]['stdout']).read_text()
    if name=='native-version': assert Path(state['stages'][name]['stdout']).read_text()=='auragaze 0.1.0\n'
    if name=='build-linux':assert sha(out/'bin/auragaze-linux-arm64')=='d4c1011d3d615f303cd8d60760c0eeb8d3f234fda74ac2dfd77aa75e4e8ae637','final Linux binary differs from accepted isolated opt4'
    if name=='receipt':
        r=read(out/'build-receipt.json');assert r['candidate_sha256']==sha(out/'bin/auragaze-linux-arm64')
        assert 'third_party/go-enry/data/centroid_model.bin' in r['source_files_sha256']
    if name=='cli':
        r=read(out/'cli.json');assert r['summary']==dict(total=420,passed=404,failed=0,expected_failures=16)
        assert r['provenance']['auragaze_binary_sha256']==sha(out/'bin/auragaze-darwin-arm64')
    if name=='samples':
        s=read(out/'samples.json')['summary'];assert s['samples']==s['auragaze_matches']==s['token_sequences_match']==3388 and s['reference_errors']==0
    if name in ('public','stress'):
        r=read(out/(name+'.json'));assert r['passed'] and r['finished_at_utc']
        assert r['candidate_sha256']==sha(out/'bin/auragaze-linux-arm64')
        if name=='public':
            pins=read(ROOT/'tests/performance/corpus.json')['projects'];assert len(r['projects'])==11
            assert {p['name']:p['commit'] for p in r['projects']}=={p['name']:p['commit'] for p in pins}
            for p in r['projects']:
                assert p['match']
                for tool,digest in p['output_sha256'].items():assert sha(out/'public-details'/f"{p['name']}-{tool}.json")==digest
        else:
            assert len(r['cases'])==14
            for case in r['cases']:
                assert case['match']
                for result in case['results'].values():assert result['exit_code']==0 and sha(out/'stress-details'/result['artifact'])==result['sha256']
                for result in case.get('extended',{}).values():
                    extended=read(out/'stress-details'/result['artifact'])
                    assert extended['exit_code']==0
    if name in ('archives','reproduction'):
        root=out/name; provenance=read(root/'provenance.json')
        assert provenance['git_revision']==state['plan']['commit']
        assert len(provenance['archives'])==(5 if name=='archives' else 1)
        sums=(root/'SHA256SUMS').read_text().splitlines()
        for entry in provenance['archives']:
            archive=root/entry['name'];assert sha(archive)==entry['sha256']
            assert f"{entry['sha256']}  {entry['name']}" in sums
            if entry['os']=='windows':
                with zipfile.ZipFile(archive) as z: payload={n:z.read(n) for n in z.namelist()}
                binary='auragaze.exe'
            else:
                with tarfile.open(archive) as t: payload={m.name:t.extractfile(m).read() for m in t.getmembers()}
                binary='auragaze'
            assert set(payload)=={binary,'README.md','LICENSE','THIRD_PARTY_NOTICES.md'}
            assert hashlib.sha256(payload[binary]).hexdigest()==entry['binary_sha256']
            for text in ['README.md','LICENSE','THIRD_PARTY_NOTICES.md']:assert payload[text]==(ROOT/text).read_bytes()
            if entry['arch']=='arm64' and entry['os'] in ('linux','darwin'):assert entry['binary_sha256']==sha(out/'bin'/f"auragaze-{entry['os']}-arm64")
            if name=='reproduction':assert sha(out/'archives'/entry['name'])==entry['sha256']

def artifacts(name,out):
    selected=[]
    if name.startswith('build-') and name in ['build-linux','build-darwin']:
        selected=[out/'bin'/f"auragaze-{name.removeprefix('build-')}-arm64"]
    single={'receipt':'build-receipt.json','root-race':'root-coverage.out','nested-race':'nested-coverage.out',
            'cli':'cli.json','samples':'samples.json','public':'public.json','stress':'stress.json','docker-smoke':'docker-smoke.json'}
    if name in single:selected.append(out/single[name])
    if name in ['public','stress']:selected.extend((out/(name+'-details')).glob('*.json'))
    if name in ['cli','samples']:selected.append(out/(name+'.md'))
    if name in ['archives','reproduction']:selected.extend(p for p in (out/name).iterdir() if p.is_file())
    return {str(p):sha(p) for p in sorted(selected)}

if __name__=='__main__':main()
