import argparse, datetime, hashlib, json, pathlib, subprocess, tarfile, zipfile
ROOT=pathlib.Path('/Users/gingeleski/Workspace/auragaze')
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=pathlib.Path,default=ROOT/'.cache/v01-final-validation')
OUT=parser.parse_args().output.resolve()
IMAGE='sha256:f67c429e2b22c0c9691c9e16cceeeee9f2033486b451f5dc0f4278a1783f742c'
def sha(data):return hashlib.sha256(data).hexdigest()
state=json.loads((OUT/'state.json').read_text())
assert state['complete'], 'Main sequential runner must finish first'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==state['plan']['commit']
metadata=[];binaries={}
for directory in ['archives','reproduction']:
    parent=OUT/directory;provenance=json.loads((parent/'provenance.json').read_text())
    assert provenance['git_revision']==state['plan']['commit']
    for row in provenance['archives']:
        archive=parent/row['name'];raw=archive.read_bytes();assert sha(raw)==row['sha256']
        entries=[];binary='auragaze.exe' if row['os']=='windows' else 'auragaze'
        expected={binary,'README.md','LICENSE','THIRD_PARTY_NOTICES.md'}
        if row['os']=='windows':
            with zipfile.ZipFile(archive) as z:
                names=z.namelist();assert names==sorted(expected)
                for info in z.infolist():
                    mode=0o100755 if info.filename==binary else 0o100644
                    assert info.create_system==3 and info.external_attr>>16==mode
                    assert info.date_time==(1980,1,1,0,0,0) and not info.is_dir()
                    entries.append({'path':info.filename,'mode':oct(mode),'bytes':info.file_size})
                content=z.read(binary)
        else:
            assert raw[:3]==b'\x1f\x8b\x08' and raw[3]==0 and raw[4:8]==b'\0'*4
            with tarfile.open(archive) as t:
                members=t.getmembers();assert [m.name for m in members]==sorted(expected)
                for m in members:
                    mode=0o755 if m.name==binary else 0o644
                    assert m.isfile() and m.mode==mode and m.uid==m.gid==m.mtime==0
                    assert m.uname==m.gname==''
                    entries.append({'path':m.name,'mode':oct(mode),'bytes':m.size})
                content=t.extractfile(binary).read()
        assert sha(content)==row['binary_sha256']
        if directory=='archives':binaries[(row['os'],row['arch'])]=content
        metadata.append({'archive':directory+'/'+row['name'],'sha256':row['sha256'],'binary_sha256':sha(content),'entries':entries})
supp=OUT/'archive-supplement';supp.mkdir()
binary=supp/'auragaze-linux-amd64';binary.write_bytes(binaries[('linux','amd64')]);binary.chmod(0o755)
assert binary.read_bytes()[:4]==b'\x7fELF' and int.from_bytes(binary.read_bytes()[18:20],'little')==62
fixture=supp/'fixture';fixture.mkdir()
(fixture/'main.go').write_text('package main\nfunc main() {}\n')
(fixture/'go.mod').write_text('module example.test/release-smoke\n\ngo 1.26\n')
checks=[]
for args in [['--version'],['analyze','all','--json','/repo']]:
    command=['docker','run','--rm','--network=none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
        '-v',str(binary)+':/candidate/auragaze:ro','-v',str(fixture)+':/repo:ro',
        '--entrypoint','/candidate/auragaze',IMAGE,*args]
    p=subprocess.run(command,capture_output=True,text=True,timeout=120)
    check={'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};checks.append(check)
    assert p.returncode==0,check
    if args==['--version']:assert p.stdout=='auragaze 0.1.0\n'
    else:
        r=json.loads(p.stdout);assert r['languages'][0]['name']=='Go' and r['languages'][0]['bytes']==len((fixture/'main.go').read_bytes())
        assert any(x['name']=='go' for x in r['ecosystems']) and not r['warnings']
after={n:sha((ROOT/n).read_bytes()) for n in state['source_before']}
assert after==state['source_before']
report={'schema_version':'1.0.0','complete':True,'passed':True,'source_commit':state['plan']['commit'],
    'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':metadata,
    'amd64_binary_sha256':sha(binary.read_bytes()),'amd64_runtime_note':'Linux amd64 executable under Docker Desktop emulation in a Linux arm64 container; execution smoke only, not native amd64 performance.',
    'reference_image_id':IMAGE,'checks':checks,'source_stable_after_supplement':True}
(OUT/'archive-supplement.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'complete':True,'archives':len(metadata),'amd64_binary_sha256':report['amd64_binary_sha256'],'checks':len(checks)},indent=2))
