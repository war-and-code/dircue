#!/usr/bin/env python3
"""Run the final source vulnerability scan with an isolated Go toolchain/cache."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone


EXPECTED_COMMIT = "e2f9ae7035e087062afe55c8335e3f43569a1d8c"
GO_TOOLCHAIN = "go1.26.6"
TOOL_MODULE = "golang.org/x/vuln"
TOOL_PACKAGE = TOOL_MODULE + "/cmd/govulncheck"
SCOPE = "./..."
CONTROLS = {
    "GOENV": "off",
    "GOWORK": "off",
    "GOFLAGS": "",
    "GOEXPERIMENT": "",
    "CGO_ENABLED": "0",
    "GOAMD64": "v1",
    "GOARM64": "v8.0",
    "GOPROXY": "https://proxy.golang.org",
    "GOSUMDB": "sum.golang.org",
    "GOPRIVATE": "",
    "GONOPROXY": "",
    "GONOSUMDB": "",
    "GOINSECURE": "",
    "GOAUTH": "off",
    "GOGC": "100",
    "GOMEMLIMIT": "off",
    "GODEBUG": "",
    "GOVULNDB": "https://vuln.go.dev",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def require_clean_commit(root: Path) -> tuple[str, str]:
    status = subprocess.check_output(
        ["git", "status", "--porcelain=v1", "--untracked-files=all"],
        cwd=root,
    )
    if status:
        raise RuntimeError("vulnerability receipt requires a clean checkout")
    commit = git(root, "rev-parse", "--verify", "HEAD")
    if commit != EXPECTED_COMMIT:
        raise RuntimeError(f"expected source commit {EXPECTED_COMMIT}, found {commit}")
    return commit, git(root, "rev-parse", "HEAD^{tree}")


def controlled_environment(output: Path) -> dict[str, str]:
    environment = {
        key: value
        for key, value in os.environ.items()
        if not key.startswith(("GO", "CGO_"))
    }
    environment.update(
        CONTROLS,
        GOTOOLCHAIN=GO_TOOLCHAIN,
        GOCACHE=str(output / "go-build-cache"),
        GOMODCACHE=str(output / "go-module-cache"),
    )
    return environment


def run_command(
    command: list[str], root: Path, environment: dict[str, str], output: Path, name: str
) -> dict[str, object]:
    started = utc_now()
    result = subprocess.run(command, cwd=root, env=environment, capture_output=True)
    stdout_path = output / f"{name}.stdout"
    stderr_path = output / f"{name}.stderr"
    stdout_path.write_bytes(result.stdout)
    stderr_path.write_bytes(result.stderr)
    return {
        "name": name,
        "command": command,
        "started_at_utc": started,
        "finished_at_utc": utc_now(),
        "exit_code": result.returncode,
        "stdout": stdout_path.name,
        "stdout_sha256": sha256(stdout_path),
        "stderr": stderr_path.name,
        "stderr_sha256": sha256(stderr_path),
    }


def require_success(result: dict[str, object]) -> None:
    if result["exit_code"] != 0:
        raise RuntimeError(
            f"{result['name']} exited {result['exit_code']}; raw output was retained"
        )


def parse_lines_between(text: str, start: str, end: str) -> list[str]:
    try:
        block = text.split(start, 1)[1].split(end, 1)[0]
    except IndexError as error:
        raise RuntimeError(f"govulncheck output omitted expected scope marker: {start!r}") from error
    rows = [line.strip() for line in block.splitlines() if line.startswith("  ")]
    if not rows:
        raise RuntimeError(f"govulncheck output contained an empty scope block: {start!r}")
    return rows


def main() -> int:
    script = Path(__file__).resolve()
    output = script.parent
    root = script.parents[3]
    receipt_path = output / "receipt.json"
    if receipt_path.exists():
        raise RuntimeError(f"refusing to overwrite existing receipt: {receipt_path}")

    commit_before, tree_before = require_clean_commit(root)
    environment = controlled_environment(output)
    launcher = shutil.which("go", path=environment.get("PATH"))
    if launcher is None:
        raise RuntimeError("Go launcher not found on PATH")

    # Resolve the checksum-verified exact compiler through the normal toolchain
    # cache, then isolate all build and module dependencies for the actual scan.
    selection = dict(environment)
    selection.pop("GOMODCACHE")
    compiler_root = subprocess.check_output(
        [launcher, "env", "GOROOT"], cwd=root, env=selection, text=True
    ).strip()
    compiler = Path(compiler_root) / "bin" / ("go.exe" if os.name == "nt" else "go")
    environment["GOTOOLCHAIN"] = "local"

    results: list[dict[str, object]] = []
    results.append(run_command([str(compiler), "version"], root, environment, output, "01-go-version"))
    require_success(results[-1])
    go_version = (output / "01-go-version.stdout").read_text().strip()
    if not go_version.startswith(f"go version {GO_TOOLCHAIN} "):
        raise RuntimeError(f"resolved compiler is not {GO_TOOLCHAIN}: {go_version}")

    results.append(
        run_command(
            [str(compiler), "list", "-m", "-json", f"{TOOL_MODULE}@latest"],
            root,
            environment,
            output,
            "02-resolve-govulncheck",
        )
    )
    require_success(results[-1])
    module = json.loads((output / "02-resolve-govulncheck.stdout").read_text())
    if module.get("Path") != TOOL_MODULE or not re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+", module.get("Version", "")):
        raise RuntimeError(f"unexpected resolved govulncheck module: {module!r}")
    tool_version = module["Version"]
    tool_spec = f"{TOOL_PACKAGE}@{tool_version}"

    results.append(
        run_command(
            [str(compiler), "mod", "download", "-json", f"{TOOL_MODULE}@{tool_version}"],
            root,
            environment,
            output,
            "03-download-govulncheck",
        )
    )
    require_success(results[-1])
    downloaded_module = json.loads((output / "03-download-govulncheck.stdout").read_text())
    if (
        downloaded_module.get("Path") != TOOL_MODULE
        or downloaded_module.get("Version") != tool_version
        or not isinstance(downloaded_module.get("Sum"), str)
        or not downloaded_module["Sum"].startswith("h1:")
        or not isinstance(downloaded_module.get("GoModSum"), str)
        or not downloaded_module["GoModSum"].startswith("h1:")
        or downloaded_module.get("Error")
    ):
        raise RuntimeError(f"unverified govulncheck module download: {downloaded_module!r}")
    for key in ("Sum", "GoModSum"):
        if module.get(key) not in (None, downloaded_module[key]):
            raise RuntimeError(f"govulncheck {key} changed between resolution and download")

    results.append(
        run_command(
            [str(compiler), "run", tool_spec, "-version"],
            root,
            environment,
            output,
            "04-govulncheck-version",
        )
    )
    require_success(results[-1])
    version_text = (output / "04-govulncheck-version.stdout").read_text()
    scanner_match = re.search(r"^Scanner: govulncheck@(v[^\s]+)$", version_text, re.MULTILINE)
    database_match = re.search(r"^DB updated: (.+)$", version_text, re.MULTILINE)
    if not scanner_match or scanner_match.group(1) != tool_version or not database_match:
        raise RuntimeError("govulncheck version output omitted the pinned tool version or DB timestamp")

    results.append(
        run_command(
            [str(compiler), "run", tool_spec, "-show", "verbose", SCOPE],
            root,
            environment,
            output,
            "05-govulncheck-scan",
        )
    )
    scan_text = (output / "05-govulncheck-scan.stdout").read_text() + (output / "05-govulncheck-scan.stderr").read_text()
    packages = parse_lines_between(
        scan_text,
        "root packages:\n",
        "Govulncheck scanned the following",
    )
    modules = parse_lines_between(
        scan_text,
        "standard library:\n",
        "=== Symbol Results ===",
    )
    reachable_match = re.search(r"Your code is affected by ([0-9]+) vulnerabilities?\.", scan_text)
    advisories = sorted(set(re.findall(r"\bGO-[0-9]{4}-[0-9]{4}\b", scan_text)))
    if not reachable_match:
        raise RuntimeError("govulncheck scan output omitted its reachable-vulnerability summary")

    commit_after, tree_after = require_clean_commit(root)
    if (commit_after, tree_after) != (commit_before, tree_before):
        raise RuntimeError("source changed during vulnerability scan")

    normalized_environment = dict(CONTROLS)
    normalized_environment.update(
        GOTOOLCHAIN="local (resolved from go1.26.6)",
        GOCACHE="<security-receipt>/go-build-cache",
        GOMODCACHE="<security-receipt>/go-module-cache",
    )
    receipt = {
        "schema_version": 1,
        "created_at_utc": utc_now(),
        "source": {
            "commit": commit_before,
            "tree": tree_before,
            "clean_before_and_after": True,
            "go_mod_sha256": sha256(root / "go.mod"),
            "go_sum_sha256": sha256(root / "go.sum"),
        },
        "runner_sha256": sha256(script),
        "toolchain": {
            "required": GO_TOOLCHAIN,
            "reported": go_version,
            "launcher": launcher,
            "resolved_compiler": str(compiler),
        },
        "govulncheck": {
            "module": TOOL_MODULE,
            "resolved_version": tool_version,
            "module_sum": downloaded_module["Sum"],
            "go_mod_sum": downloaded_module["GoModSum"],
            "database": CONTROLS["GOVULNDB"],
            "database_updated": database_match.group(1),
            "scope_pattern": SCOPE,
            "root_packages": packages,
            "modules_and_standard_library": modules,
            "reachable_vulnerabilities": int(reachable_match.group(1)),
            "reported_advisory_ids": advisories,
            "scan_exit_code": results[-1]["exit_code"],
        },
        "environment": normalized_environment,
        "commands": results,
    }
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(receipt_path)
    if results[-1]["exit_code"] != 0:
        print("govulncheck reported a nonzero result; inspect preserved output", file=sys.stderr)
        return int(results[-1]["exit_code"])
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(1)
