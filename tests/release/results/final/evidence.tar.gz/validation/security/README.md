# Final govulncheck receipt

Prepared for the frozen source commit
`e2f9ae7035e087062afe55c8335e3f43569a1d8c`. The runner has not been
executed yet.

After the final package checks finish and the compute gate opens, run exactly:

```sh
python3 .cache/v01-final-validation/security/run.py
```

The runner refuses a dirty or different checkout, resolves exactly Go 1.26.6,
uses fresh isolated Go build and module caches, resolves
`golang.org/x/vuln@latest` once, downloads that exact resolved module and
requires both its module and `go.mod` checksums, then pins it for both the
version probe and `govulncheck -show verbose ./...`. It preserves stdout and
stderr from every command and writes `receipt.json` with:

- source commit, tree, `go.mod`, and `go.sum` hashes;
- resolved Go and govulncheck versions plus module checksums;
- vulnerability database update timestamp;
- every matched root package and scanned module;
- reachable-vulnerability count and every reported advisory ID;
- exact commands, exit statuses, output paths, and output hashes.

The prior RC scan used these commands directly:

```sh
go version
go run golang.org/x/vuln/cmd/govulncheck@latest -version
go run golang.org/x/vuln/cmd/govulncheck@latest -show verbose ./...
```

That scan used Go 1.26.6 and govulncheck v1.7.0 against a database updated at
2026-09-02 19:12:04 UTC. It covered nine root packages, 25 modules plus the Go
standard library, found no symbol-reachable vulnerabilities, and reported four
unreachable `golang.org/x/crypto` advisories: GO-2026-6355, GO-2026-6354,
GO-2026-6303, and GO-2026-5932. The committed historical transcript remains at
`tests/security/results/govulncheck-2026-09-07.txt`.
